# views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Contact, Product, Category, Order
from datetime import datetime
from math import ceil
import json

def index(request):
    categories = Category.objects.all()
    products_by_category = []
    
    for category in categories:
        products = Product.objects.filter(category=category)
        n = len(products)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        products_by_category.append({'category': category, 'products': products, 'nSlides': range(1, nSlides)})
    
    context = {
        'categories': categories,
        'products_by_category': products_by_category
    }
    return render(request, 'index.html', context)

from django.utils import timezone

def checkout(request):
    if request.method == 'POST':
        # Retrieve form data
        full_name = request.POST.get('full_name')
        address = request.POST.get('address')
        city = request.POST.get('city')
        state = request.POST.get('state')
        zip_code = request.POST.get('zip_code')
        email = request.POST.get('email')
        phone = request.POST.get('phone')

        try:
            # Create Order instance and save to database
            order = Order(
                full_name=full_name,
                address=address,
                city=city,
                state=state,
                zip_code=zip_code,
                email=email,
                phone=phone,
                order_date=timezone.now()  # Set order_date to current date and time
            )
            order.save()

            # Display a success message
            messages.success(request, 'Your order has been placed successfully!')
            return redirect('checkout')

        except Exception as e:
            messages.error(request, f'Error placing order: {str(e)}')
            return redirect('checkout')
    else:
        # Handle GET request
        return render(request, 'checkout.html')

def order_summary(request):
    # Retrieve orders from the database
    orders = Order.objects.all()

    # Pass orders to the template for rendering
    return render(request, 'order_summary.html', {'orders': orders})

def contact(request):
    if request.method == "POST":
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        desc = request.POST.get('desc', '')

        # Get the current date and time
        current_datetime = datetime.now()
        # Create a Contact object and save it to the database
        contact = Contact(name=name, email=email, phone=phone, desc=desc, created_at=current_datetime)
        contact.save()

        # Display a success message
        messages.success(request, 'Your message has been submitted successfully!')

        # Optionally, you can redirect the user to another page after submission
        # return redirect('success_page')

    return render(request, 'contact.html')

def productView(request, product_id):
    # Fetch the product from the database based on the product_id
    product = Product.objects.get(pk=product_id)
    return render(request, "prodview.html", {'product': product})

# Define other views like tracker, about, signup, login, and logout here...

def tracker(request):
    return render(request,"tracker.html")
    
def about(request):
    return render(request, "about.html")

def signup(request):    
    return render(request, "signup.html")

def login(request):
    return render(request, "login.html")

def logout(request):
    return redirect('login')
